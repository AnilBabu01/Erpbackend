const nodemailer = require("nodemailer");

const sendEmail = async (options) => {
  const transporter = nodemailer.createTransport({
    service: "gmail",
    host: "smtp.gmail.com",
    auth: {
      user: "abtechzone46@gmail.com",
      pass: "gotxjyfopqekkmjf",
    },
  });

  const message = {
    from: "abtechzone46@gmail.com",
    to: options.email,
    subject: options.subject,
    html: options.message,
  };

  await transporter.sendMail(message);
};

module.exports = sendEmail;
